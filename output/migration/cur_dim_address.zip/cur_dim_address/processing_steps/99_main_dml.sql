ALTER TABLE ${cur_schema}.DIM_ADDRESS DROP IF EXISTS   PARTITION(etl_dt = '${batch_date}');

/* ==============[Group.23]============== */
INSERT INTO ${cur_schema}.DIM_ADDRESS PARTITION(etl_dt = '${batch_date}') (
  OWNER_ID, /* None */
  ADDRESS_OWNER_TYPE, /* None */
  ADDRESS_TYPE, /* None */
  ADDRESS_LINE_1, /* None */
  ADDRESS_LINE_2, /* None */
  ADDRESS_LINE_3, /* None */
  ADDRESS_LINE_4, /* None */
  CITY, /* None */
  STATE, /* None */
  POSTCODE, /* None */
  COUNTRY, /* None */
  ADDRESS_CREATE_DATE, /* None */
  ADDRESS_UPDATE_DATE, /* None */
  LINE_OF_BUSINESS, /* None */
  SOURCE_NAME, /* None */
  SOURCE_RECORD_ID, /* None */
  ETL_TIMESTAMP
)
SELECT
  T1.OWNER_ID AS OWNER_ID, /* None */
  T1.ADDRESS_OWNER_TYPE AS ADDRESS_OWNER_TYPE, /* None */
  T1.ADDRESS_TYPE AS ADDRESS_TYPE, /* None */
  T1.ADDRESS_LINE_1 AS ADDRESS_LINE_1, /* None */
  T1.ADDRESS_LINE_2 AS ADDRESS_LINE_2, /* None */
  T1.ADDRESS_LINE_3 AS ADDRESS_LINE_3, /* None */
  T1.ADDRESS_LINE_4 AS ADDRESS_LINE_4, /* None */
  T1.CITY AS CITY, /* None */
  T1.STATE AS STATE, /* None */
  T1.POSTCODE AS POSTCODE, /* None */
  T1.COUNTRY AS COUNTRY, /* None */
  T1.ADDRESS_CREATE_DATE AS ADDRESS_CREATE_DATE, /* None */
  T1.ADDRESS_UPDATE_DATE AS ADDRESS_UPDATE_DATE, /* None */
  T1.LINE_OF_BUSINESS AS LINE_OF_BUSINESS, /* None */
  T1.SOURCE_NAME AS SOURCE_NAME, /* None */
  T1.SOURCE_RECORD_ID AS SOURCE_RECORD_ID, /* None */
  '${batch_timestamp}' AS ETL_TIMESTAMP
FROM (
  SELECT
    *
  FROM ${cur_schema}.TEMP_DIM_ACCOUNT_ADDRESS
  UNION ALL
  SELECT
    *
  FROM ${cur_schema}.TEMP_DIM_TRADER_ADDRESS
  UNION ALL
  SELECT
    *
  FROM ${cur_schema}.TEMP_DIM_BRANCH_ADDRESS
  UNION ALL
  SELECT
    *
  FROM ${cur_schema}.TEMP_DIM_CUSTOMER_ADDRESS
) AS T1 /* None */
WHERE
  1 = 1;